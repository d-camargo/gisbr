# -*- coding: utf-8 -*-
"""Motor do diagnostico. Protocolos: wfs, arcgis, geobr (code|bbox), osm, arquivo.

Fontes filtradas por bbox sao recortadas pelo POLIGONO do municipio (native:clip)
para nao trazer feicoes de municipios vizinhos. Camadas sem feicoes sao puladas
com aviso no Log.
"""
import os

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QStandardPaths
from qgis.core import QgsProject, QgsVectorLayer, QgsVectorFileWriter

from .connectors import wfs, basemap, arcgis_rest, osm, local_file, ibge_agregados, zip_remoto, cog_raster
from .sources import SOURCES
from . import (catalog, catalog_censo, censo_join, osm_pipeline, poi_pipeline,
               agro_pipeline)

_UF_POR_CODIGO = {
    "11": "RO", "12": "AC", "13": "AM", "14": "RR", "15": "PA", "16": "AP",
    "17": "TO", "21": "MA", "22": "PI", "23": "CE", "24": "RN", "25": "PB",
    "26": "PE", "27": "AL", "28": "SE", "29": "BA", "31": "MG", "32": "ES",
    "33": "RJ", "35": "SP", "41": "PR", "42": "SC", "43": "RS", "50": "MS",
    "51": "MT", "52": "GO", "53": "DF",
}

_PROTOCOLOS = ("wfs", "arcgis", "geobr", "osm", "arquivo", "ibge_tabular", "zip_remoto")

_QSETTINGS_PASTA_MANUAL = "gisbr/pasta_downloads_manuais"


def _pasta_downloads_manuais():
    """Pasta de downloads manuais: QSettings com fallback para a pasta de
    Downloads do sistema (o painel persiste a escolha do usuario)."""
    pasta = QSettings().value(_QSETTINGS_PASTA_MANUAL, "")
    if pasta and str(pasta).strip():
        return str(pasta).strip()
    return QStandardPaths.writableLocation(
        QStandardPaths.StandardLocation.DownloadLocation)


def _por_id(ids):
    return [s for s in SOURCES if s["id"] in ids]


def _filtro_para(s, code_muni, nome_muni):
    f = s.get("filtro") or {"tipo": "bbox"}
    t = f.get("tipo")
    if t == "cql_codigo":
        return "{} = {}".format(f["campo"], int(code_muni)), False
    if t == "cql_nome":
        nome = (nome_muni or "").replace("'", "''")
        return "{} = '{}'".format(f["campo"], nome), False
    return None, True


def _usou_bbox(s, usa_bbox):
    if s.get("protocolo") == "ibge_tabular":
        return False
    if s.get("protocolo") == "geobr":
        return s.get("recorte", "code") == "bbox"
    return usa_bbox


def _layers_existentes(gpkg_path):
    if not os.path.exists(gpkg_path):
        return set()
    vl = QgsVectorLayer(gpkg_path, "probe", "ogr")
    if not vl.isValid():
        return set()
    nomes = set()
    for sub in vl.dataProvider().subLayers():
        parts = sub.split("!!::!!")
        if len(parts) > 1:
            nomes.add(parts[1])
    return nomes


def _grava_gpkg(layer, gpkg_path, layer_name):
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = layer_name
    opts.actionOnExistingFile = (
        QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer if os.path.exists(gpkg_path)
        else QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile
    )
    ctx = QgsProject.instance().transformContext()
    res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, gpkg_path, ctx, opts)
    return res[0] == QgsVectorFileWriter.WriterError.NoError, res[1]


def _resolve_out(out, layer_name):
    if isinstance(out, str):
        return QgsProject.instance().mapLayer(out) or QgsVectorLayer(out, layer_name, "ogr")
    return out


def _invalida(layer_name, msg):
    inv = QgsVectorLayer("", layer_name, "ogr")
    inv.error_msg = msg
    return inv


def _municipio_poligono(code_muni):
    """Poligono do municipio (read_municipality) p/ recorte. None se falhar."""
    import processing
    try:
        out = processing.run("gisbr:read_municipality", {
            "CODE": str(code_muni), "SIMPLIFIED": True, "OUTPUT": "TEMPORARY_OUTPUT",
        })["OUTPUT"]
    except Exception:
        return None
    out = _resolve_out(out, "municipio")
    return out if (out is not None and out.isValid()) else None


def _recorta_poligono(layer, poligono, layer_name):
    import processing
    try:
        out = processing.run("native:clip", {
            "INPUT": layer, "OVERLAY": poligono, "OUTPUT": "TEMPORARY_OUTPUT",
        })["OUTPUT"]
        return _resolve_out(out, layer_name)
    except Exception as exc:
        return _invalida(layer_name, "recorte por poligono: {}".format(exc))


def _carrega_geobr(s, code_muni, layer_name, ano=None):
    """recorte 'code' filtra por code_muni; 'bbox' baixa nacional (sera recortado
    pelo poligono no carregar_fontes)."""
    import processing
    if s.get("requer_parquet"):
        from . import capabilities
        if capabilities.parquet_backend() is None:
            return _invalida(layer_name, "requer driver Parquet ou pyarrow (fonte v2)")
    algo = s["algo"]
    code_param = str(code_muni) if s.get("recorte", "code") == "code" else "all"
    params = {
        "CODE": code_param, "SIMPLIFIED": True, "OUTPUT": "TEMPORARY_OUTPUT",
    }
    ano_invalido_msg = None
    if ano is not None:
        try:
            years = catalog.available_years("census_tract")
            idx = years.index(int(ano))
            params["YEAR"] = idx
        except Exception as exc:
            ano_invalido_msg = "ano {} indisponivel para setores censitarios ({})".format(ano, exc)
    try:
        out = processing.run("gisbr:{}".format(algo), params)["OUTPUT"]
    except Exception as exc:
        return _invalida(layer_name, "geobr {}: {}".format(algo, exc))
    res_layer = _resolve_out(out, layer_name)
    if res_layer is not None and ano_invalido_msg:
        res_layer.ano_invalido_msg = ano_invalido_msg
    return res_layer


def _msg_arquivo_ausente(s, pasta):
    """Aviso de 'pulou' quando o arquivo de download manual nao esta na pasta.

    Idioma-base do plugin: ingles (traduzido pelo .ts no contexto 'GisBR').
    Diz onde foi procurado e como obter a base, para o usuario nao achar que
    e falha do plugin.
    """
    url = s.get("origem_url")
    if url:
        return QCoreApplication.translate(
            "GisBR",
            "file not found in the manual downloads folder ({folder}); this "
            "dataset requires a gov.br login, so download it from {url} and "
            "save it in that folder"
        ).format(folder=pasta, url=url)
    return QCoreApplication.translate(
        "GisBR",
        "file not found in the manual downloads folder ({folder}); download "
        "the dataset from its official portal and save it in that folder"
    ).format(folder=pasta)


def _msg_fonte_indisponivel(s):
    """Aviso de 'pulou' quando a fonte possui a chave 'indisponivel'.

    Formata motivo e origem_url para orientar o usuario (D8).
    """
    motivo = s.get("indisponivel")
    url = s.get("origem_url")
    if url:
        return QCoreApplication.translate(
            "GisBR",
            "source unavailable ({reason}); see official portal at {url}"
        ).format(reason=motivo, url=url)
    return QCoreApplication.translate(
        "GisBR",
        "source unavailable ({reason})"
    ).format(reason=motivo)


def _busca_camada(s, layer_name, uf, cql, usa_bbox, bbox, code_muni, gpkg_path,
                  feedback=None, caminho_manual=None, censo_ano=None, nome_muni=None):
    proto = s.get("protocolo")
    srs = s.get("srs", "EPSG:4674")
    if proto == "wfs":
        type_name = s["type_name"].replace("{uf}", uf)
        return wfs.fetch_layer(s["endpoint"], type_name, layer_name, srs=srs,
                               cql_filter=cql, bbox=(bbox if usa_bbox else None),
                               feedback=feedback)
    if proto == "arcgis":
        return arcgis_rest.fetch_layer(s["endpoint"], s["layer_id"], layer_name,
                                       srs=srs, where=cql,
                                       bbox=(bbox if usa_bbox else None),
                                       feedback=feedback)
    if proto == "geobr":
        ano = censo_ano if s.get("id") == "geobr_setores" else None
        return _carrega_geobr(s, code_muni, layer_name, ano=ano)
    if proto == "arquivo":
        return local_file.fetch_layer(caminho_manual, layer_name, srs=srs,
                                      feedback=feedback)
    if proto == "zip_remoto":
        url = s.get("url") or s.get("endpoint") or s.get("origem_url")
        subset = s.get("subset")
        return zip_remoto.fetch_layer(url, layer_name, srs=srs, subset=subset,
                                      feedback=feedback)
    if proto == "ibge_tabular":
        agregado = s["agregado"]
        variaveis = s.get("variaveis", "all")
        classificacao = s.get("classificacao")
        periodo = s.get("periodo_default", "-1")
        tbl = ibge_agregados.fetch_layer(
            agregado, code_muni, layer_name,
            variaveis=variaveis, periodo=periodo,
            classificacao=classificacao, feedback=feedback
        )
        if tbl is None or not tbl.isValid():
            return tbl
        poly_layer, rel = agro_pipeline.tabela_para_camada(
            tbl, code_muni, nome_muni=nome_muni,
            layer_name=layer_name, feedback=feedback
        )
        if poly_layer is not None:
            poly_layer.relatorio = rel
            for prop in ("data_extracao", "fonte"):
                val = tbl.customProperty(prop)
                if val is not None:
                    poly_layer.setCustomProperty(prop, val)
        return poly_layer
    return None


def carregar_fontes(source_ids, code_muni, nome_muni, bbox, gpkg_path,
                    add_basemap=False, force=False, feedback=None,
                    *, censo_ano=None, censo_datasets=(), mapbiomas_ano=None):
    def log(m):
        if feedback is not None:
            feedback.pushInfo(m)

    if gpkg_path and not gpkg_path.lower().endswith(".gpkg"):
        gpkg_path = gpkg_path + ".gpkg"

    uf = _UF_POR_CODIGO.get(str(code_muni)[:2], "").lower()
    res = {"ok": [], "falhou": [], "pulou": []}
    existentes = _layers_existentes(gpkg_path)
    poligono = None
    poligono_tentado = False


    raster_sources = [s for s in _por_id(source_ids) if s.get("protocolo") == "raster_cog"]
    for s in raster_sources:
        sid = s["id"]
        if sid == "mapbiomas_cobertura" and mapbiomas_ano:
            ano = mapbiomas_ano
        else:
            ano = s.get("ano_default") or s.get("ano", "")
        gpkg_dir = os.path.dirname(gpkg_path) if gpkg_path else ""
        tif_filename = "{}_{}_{}.tif".format(sid, ano, code_muni) if ano else "{}_{}.tif".format(sid, code_muni)
        tif_path = os.path.join(gpkg_dir, tif_filename)

        layer_name = "{}_{}".format(sid, code_muni)

        if (not force) and os.path.exists(tif_path):
            res["pulou"].append((sid, "ja existe ({}) (marque 'Atualizar bases já baixadas' para rebaixar)".format(tif_filename)))
            continue

        if not poligono_tentado:
            poligono = _municipio_poligono(code_muni)
            poligono_tentado = True
        if poligono is None:
            res["falhou"].append((sid, "nao obtive o poligono do municipio p/ recorte"))
            continue

        url_template = s.get("url_template")
        if url_template and ano:
            url = url_template.format(ano=ano)
        else:
            url = s.get("endpoint") or s.get("url") or s.get("origem_url")
        rl = cog_raster.fetch_layer(
            url,
            poligono,
            tif_path,
            layer_name=layer_name,
            feedback=feedback
        )

        if rl is None or not rl.isValid():
            msg = getattr(rl, "error_msg", "camada raster invalida") if rl else "falha no conector cog_raster"
            res["falhou"].append((sid, msg))
            continue

        proj = QgsProject.instance()
        proj.addMapLayer(rl, False)
        proj.layerTreeRoot().addLayer(rl)

        res["ok"].append(sid)
        log("OK: {}".format(layer_name))

    raster_ids = set(s["id"] for s in raster_sources)
    source_ids = [sid for sid in source_ids if sid not in raster_ids]

    # ponytail: OSM é special-case — despacha pipelines especificos por fonte (osm_vias, osm_pois, etc)
    osm_sources = [s for s in _por_id(source_ids) if s.get("protocolo") == "osm"]
    for osm_source in osm_sources:
        sid = osm_source["id"]
        if sid == "osm_vias":
            if (not force) and osm_pipeline.osm_vias_ja_existe(existentes, code_muni):
                res["pulou"].append((sid, "ja existe no GeoPackage (osm_links_{}/osm_nodes_{}) (marque 'Atualizar bases já baixadas' para rebaixar)".format(code_muni, code_muni)))
            else:
                result = osm_pipeline.build_osm_municipal_network(code_muni, nome_muni, gpkg_path, force=force, feedback=feedback)
                meta = result.get("metadata", {})
                if meta.get("cancelado"):
                    # Passo 6c: botao "Cancelar" do painel -> feedback.cancel();
                    # sem excecao, a fonte volta como pulada (nao falhou).
                    res["pulou"].append((sid, "cancelado pelo usuário"))
                    log("Aviso: {} — cancelado pelo usuário".format(sid))
                elif meta.get("sem_vias"):
                    # regra da casa: 0 feições entra em pulou com aviso, nao em falhou
                    res["pulou"].append((sid, meta.get("erro", "nenhuma via")))
                    log("Aviso: {} — {}".format(sid, meta.get("erro", "nenhuma via")))
                elif meta.get("gpkg_ok"):
                    # Carregar DO GPKG, não da memory — persistence real
                    osm_links = QgsVectorLayer("{}|layername=osm_links_{}".format(gpkg_path, code_muni), "osm_links - {}".format(nome_muni or code_muni), "ogr")
                    osm_nodes = QgsVectorLayer("{}|layername=osm_nodes_{}".format(gpkg_path, code_muni), "osm_nodes - {}".format(nome_muni or code_muni), "ogr")
                    if osm_links.isValid():
                        QgsProject.instance().addMapLayer(osm_links)
                        log("OK: osm_links (GPKG)")
                    if osm_nodes.isValid():
                        QgsProject.instance().addMapLayer(osm_nodes)
                        log("OK: osm_nodes (GPKG)")
                    # osm_problemas é aditivo: GPKGs antigos (pre-verificacao
                    # topologica) nao tem essa camada, e isso nao falha a fonte.
                    osm_problemas = QgsVectorLayer("{}|layername=osm_problemas_{}".format(gpkg_path, code_muni), "osm_problemas - {}".format(nome_muni or code_muni), "ogr")
                    if osm_problemas.isValid():
                        QgsProject.instance().addMapLayer(osm_problemas)
                        log("OK: osm_problemas (GPKG)")
                    if osm_links.isValid() and osm_nodes.isValid():
                        res["ok"].append(sid)
                    else:
                        res["falhou"].append((sid, "falha ao carregar OSM do GPKG"))
                else:
                    res["falhou"].append((sid, "OSM: pipeline falhou — {}".format(meta.get("erro") or "desconhecido")))
        elif sid == "osm_pois":
            poi_layer_name = "osm_pois_{}".format(code_muni)
            area_layer_name = "osm_pois_area_{}".format(code_muni)
            if (not force) and poi_layer_name in existentes and area_layer_name in existentes:
                res["pulou"].append((sid, "ja existe no GeoPackage ({}/{}) (marque 'Atualizar bases já baixadas' para rebaixar)".format(poi_layer_name, area_layer_name)))
            else:
                result = poi_pipeline.build_osm_municipal_pois(code_muni, nome_muni, gpkg_path, force=force, feedback=feedback)
                meta = result.get("metadata", {})
                if meta.get("sem_pois"):
                    # regra da casa: 0 feições entra em pulou com aviso, nao em falhou
                    res["pulou"].append((sid, meta.get("erro", "nenhum POI")))
                    log("Aviso: {} — {}".format(sid, meta.get("erro", "nenhum POI")))
                elif meta.get("gpkg_ok"):
                    # Carregar DO GPKG, não da memory — persistence real
                    osm_pois = QgsVectorLayer("{}|layername={}".format(gpkg_path, poi_layer_name), "osm_pois - {}".format(nome_muni or code_muni), "ogr")
                    if osm_pois.isValid():
                        QgsProject.instance().addMapLayer(osm_pois)
                        log("OK: osm_pois (GPKG)")
                    if meta.get("area_layer_criada"):
                        osm_pois_area = QgsVectorLayer("{}|layername={}".format(gpkg_path, area_layer_name), "osm_pois_area - {}".format(nome_muni or code_muni), "ogr")
                        if osm_pois_area.isValid():
                            QgsProject.instance().addMapLayer(osm_pois_area)
                            log("OK: osm_pois_area (GPKG)")
                    if osm_pois.isValid():
                        res["ok"].append(sid)
                    else:
                        res["falhou"].append((sid, "falha ao carregar OSM POI do GPKG"))
                else:
                    res["falhou"].append((sid, "OSM POI: pipeline falhou — {}".format(meta.get("erro", "desconhecido"))))
        else:
            res["falhou"].append((sid, "fonte OSM desconhecida: {}".format(sid)))

    osm_ids = set(s["id"] for s in osm_sources)
    source_ids = [s for s in source_ids if s not in osm_ids]

    for s in _por_id(source_ids):
        proto = s.get("protocolo")
        if proto == "basemap":
            continue
        if proto not in _PROTOCOLOS:
            res["pulou"].append((s["id"], "conector {} ainda nao implementado".format(proto)))
            continue

        layer_name = "{}_{}".format(s["id"], code_muni)
        if (not force) and layer_name in existentes:
            res["pulou"].append((s["id"], "ja existe no GeoPackage ({}) (marque 'Atualizar bases já baixadas' para rebaixar)".format(layer_name)))
            continue

        if s.get("indisponivel"):
            res["pulou"].append((s["id"], _msg_fonte_indisponivel(s)))
            continue

        # arquivo de download manual ausente e 'pulou' (como requer_parquet):
        # o aviso diz qual pasta foi olhada e de onde baixar
        caminho_manual = None
        if proto == "arquivo":
            pasta = _pasta_downloads_manuais()
            caminho_manual = local_file.resolve_arquivo(pasta, s.get("arquivo_glob") or [])
            if caminho_manual is None:
                res["pulou"].append((s["id"], _msg_arquivo_ausente(s, pasta)))
                continue

        cql, usa_bbox = _filtro_para(s, code_muni, nome_muni)
        layer = _busca_camada(s, layer_name, uf, cql, usa_bbox, bbox, code_muni,
                              gpkg_path, feedback=feedback,
                              caminho_manual=caminho_manual,
                              censo_ano=censo_ano,
                              nome_muni=nome_muni)
        if layer is None or not layer.isValid():
            msg = getattr(layer, "error_msg", "camada invalida") if layer else "protocolo desconhecido"
            res["falhou"].append((s["id"], msg))
            continue

        # base nao retornou nada (ex.: aterro sem feicao no municipio)
        if layer.featureCount() == 0:
            res["pulou"].append((s["id"], "sem feicoes para este municipio (base nao retornou nada)"))
            continue

        rel = getattr(layer, "relatorio", None)
        if rel and rel.get("produtos_aproveitados") == 0:
            msg = "sem produtos com valor para este municipio"
            if rel.get("avisos"):
                msg = rel["avisos"][0]
            res["pulou"].append((s["id"], msg))
            log("Aviso: {} — {}".format(s["id"], msg))
            continue

        if rel and rel.get("avisos"):
            for aviso in rel["avisos"]:
                log("Aviso: {}".format(aviso))

        # fontes filtradas por bbox -> recorta pelo POLIGONO do municipio
        if _usou_bbox(s, usa_bbox):
            if not poligono_tentado:
                poligono = _municipio_poligono(code_muni)
                poligono_tentado = True
            if poligono is None:
                res["falhou"].append((s["id"], "nao obtive o poligono do municipio p/ recorte"))
                continue
            layer = _recorta_poligono(layer, poligono, layer_name)
            if layer is None or not layer.isValid():
                res["falhou"].append((s["id"], getattr(layer, "error_msg", "falha no recorte")))
                continue
            if layer.featureCount() == 0:
                res["pulou"].append((s["id"], "sem feicoes dentro do municipio (apos recorte)"))
                continue

        if s.get("id") == "geobr_setores":
            ano_invalido_msg = getattr(layer, "ano_invalido_msg", None)
            if ano_invalido_msg:
                log("Aviso: {}".format(ano_invalido_msg))
            elif censo_ano and censo_datasets:
                # D10: tamanho do download ANTES de baixar
                try:
                    for _ds in censo_datasets:
                        _row = catalog_censo.select(censo_ano, _ds)
                        _size = _row.get("size", 0)
                        log("[censo] {}{}".format(
                            _row.get("file_name", "?"),
                            " — {:.1f} MB (baixa uma vez; fica em cache)".format(
                                _size / (1024.0 * 1024.0)) if _size else ""))
                except Exception as exc:
                    log("Aviso: catalogo censobr indisponivel ({})".format(exc))
                try:
                    joined_layer, rel = censo_join.anexar_censo(
                        layer, censo_ano, censo_datasets, code_muni=code_muni,
                        feedback=feedback
                    )
                    for _info in rel.get("infos", []):
                        log(_info)
                    for _aviso in rel.get("avisos", []):
                        log("Aviso: {}".format(_aviso))
                    if rel.get("datasets_ok"):
                        log("censobr: setores casados: {} | sem correspondencia: {}".format(
                            rel.get("casados", 0), rel.get("sem_par", 0)))
                    if joined_layer is not None and getattr(joined_layer, "isValid", lambda: True)():
                        layer = joined_layer
                except Exception as exc:
                    log("Aviso: {}".format(exc))

        ok, msg = _grava_gpkg(layer, gpkg_path, layer_name)
        if not ok:
            res["falhou"].append((s["id"], "gravar GeoPackage: {}".format(msg)))
            continue
        existentes.add(layer_name)

        nome_proj = "{} - {}".format(s.get("nome", s["id"]), nome_muni or code_muni)
        gl = QgsVectorLayer("{}|layername={}".format(gpkg_path, layer_name), nome_proj, "ogr")
        if gl.isValid():
            QgsProject.instance().addMapLayer(gl)
            res["ok"].append(s["id"])
            log("OK: {}".format(layer_name))
        else:
            res["falhou"].append((s["id"], "camada do GeoPackage invalida"))

    if add_basemap:
        bl = basemap.satellite_layer()
        if bl.isValid():
            proj = QgsProject.instance()
            proj.addMapLayer(bl, False)            # nao adiciona a arvore ainda
            proj.layerTreeRoot().addLayer(bl)      # anexa como ULTIMO filho = fundo
            log("basemap de satelite adicionado (ao fundo)")

    return res
